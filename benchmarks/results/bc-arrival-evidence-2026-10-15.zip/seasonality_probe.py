from pathlib import Path
import requests,json,time,datetime
root=Path('/tmp/what-to-id-capacity-arrivals');session=requests.Session();session.headers['User-Agent']='what-to-id capacity audit (public histogram-only research)'
last=0

def get(url,params=None):
 global last
 wait=1.1-(time.monotonic()-last)
 if wait>0:time.sleep(wait)
 r=session.get(url,params=params,timeout=60);last=time.monotonic();r.raise_for_status();return r

spec=get('https://api.inaturalist.org/v1/swagger.json').json();definitions={}
for item in spec['paths']['/observations/histogram']['get']['parameters']:
 name=item.get('$ref','').split('/')[-1]
 parameter=spec['parameters'][name]if name else item
 if parameter.get('name')in ['date_field','interval','created_d1','created_d2','created_on','quality_grade','photos','place_id']:definitions[parameter['name']]=parameter
root.joinpath('seasonality-official-parameters.json').write_text(json.dumps({'source':'https://api.inaturalist.org/v1/swagger.json','retrieved_at_UTC':datetime.datetime.now(datetime.UTC).isoformat(),'parameters':definitions},indent=2))
print('OFFICIAL',json.dumps(definitions,indent=2),flush=True)
base={'place_id':7085,'photos':'true','date_field':'created','interval':'day','created_d1':'2025-10-15','created_d2':'2026-10-14'}
for name,grades in [('allgrades','needs_id,research,casual'),('needsid','needs_id')]:
 params={**base,'quality_grade':grades};r=get('https://api.inaturalist.org/v1/observations/histogram',params)
 record={'endpoint':'https://api.inaturalist.org/v1/observations/histogram','request_url':r.url,'params':params,'retrieved_at_UTC':datetime.datetime.now(datetime.UTC).isoformat(),'status_code':r.status_code,'response':r.json(),'interpretation':'Retrospective counts of currently visible photo observations by created day, using their current quality and photo state; not historical eligibility or photo-addition/updated-record deltas.'}
 root.joinpath(f'seasonality-{name}-raw.json').write_text(json.dumps(record,indent=2));print(name,'responsekeys',list(record['response']),'results keys',list(record['response'].get('results',{})),flush=True)
