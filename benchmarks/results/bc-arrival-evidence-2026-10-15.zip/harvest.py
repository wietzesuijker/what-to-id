from pathlib import Path
import subprocess,json,zipfile,io,re,ast,datetime,time
root=Path('/tmp/what-to-id-capacity-arrivals')
runs=json.loads(root.joinpath('runs.json').read_text())['workflow_runs']
results=[]
for i,run in enumerate(runs):
 path=root/f'{run["id"]}.zip'
 record={key:run.get(key)for key in ['id','run_number','event','status','conclusion','created_at','updated_at','run_started_at','head_sha','html_url']}
 if not path.exists():
  call=subprocess.run(['gh','api',f'repos/PollockLab/what-to-id/actions/runs/{run["id"]}/logs'],capture_output=True)
  if call.returncode:
   record['log_error']=call.stderr.decode();results.append(record);continue
  path.write_bytes(call.stdout)
 with zipfile.ZipFile(path)as archive:
  lines=[]
  for name in archive.namelist():
   if name.endswith('.txt') and '/system.txt' not in name:
    text=archive.read(name).decode('utf-8-sig')
    for line in text.splitlines():
     match=re.search(r'INFO what_to_id: (sync|reconcile): (\{.*\})',line)
     if match:
      payload=ast.literal_eval(match[2]);record[match[1]]=payload;lines.append(line)
     elif ('::warning::'in line and 'echo 'not in line)or('ERROR'in line)or('changed_since'in line):lines.append(line)
  record['evidence_lines']=lines
  record['raw_log_zip']=str(path)
 results.append(record)
 root.joinpath('run_evidence.json').write_text(json.dumps(results,indent=2))
 print(i+1,run['created_at'],run['event'],'sync',record.get('sync',{}).get('added'),'replaced',record.get('sync',{}).get('replaced'),flush=True)
 # At most one logs call a second, well below the requested 60/minute cap.
 time.sleep(1.1)
root.joinpath('run_evidence.json').write_text(json.dumps(results,indent=2))
