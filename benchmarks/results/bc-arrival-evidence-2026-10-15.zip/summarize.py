from pathlib import Path
import json,datetime,statistics,collections
root=Path('/tmp/what-to-id-capacity-arrivals');rows=json.loads((root/'run_evidence.json').read_text())
def dt(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def quantile(values,q):
 values=sorted(values);at=(len(values)-1)*q;lo=int(at);return values[lo]+(values[min(lo+1,len(values)-1)]-values[lo])*(at-lo)
ordered=sorted(rows,key=lambda r:r['created_at']);previous=None;overlaps=[]
for r in ordered:
 s=r.get('sync')
 if not s:continue
 s['eligible_deliveries_upper_bound']=s['added']+s['replaced']
 s['query_window_hours']=(dt(s['since'])-dt(s['asked_from'])).total_seconds()/3600
 if previous:
  s['cursor_advance_hours']=(dt(s['since'])-dt(previous['since'])).total_seconds()/3600
  s['observed_query_overlap_hours']=(dt(previous['since'])-dt(s['asked_from'])).total_seconds()/3600
  overlaps.append(s['observed_query_overlap_hours'])
 previous=s
 daily=dt(r['created_at']).date().isoformat()
 r['utc_day']=daily
period=[r for r in ordered if '2026-10-01'<=r.get('utc_day','')<='2026-10-14']
days={}
for r in period:
 day=days.setdefault(r['utc_day'],{'runs':0,'scheduled':0,'added':0,'replaced':0,'dropped':0,'reconcile_added':0,'reconcile_gone':0,'eligible_deliveries_upper_bound':0,'run_ids':[]})
 day['runs']+=1;day['scheduled']+=r['event']=='schedule';day['run_ids'].append(r['id'])
 for k in ['added','replaced','dropped','eligible_deliveries_upper_bound']:day[k]+=r['sync'][k]
 for k in ['reconcile_added','reconcile_gone']:day[k]+=r.get('reconcile',{}).get(k,0)
metrics={}
for k in ['added','replaced','dropped','eligible_deliveries_upper_bound','reconcile_added','reconcile_gone']:
 v=[d[k]for d in days.values()];metrics[k]={'total':sum(v),'mean_per_UTC_day':statistics.mean(v),'median':statistics.median(v),'p90_linear_interpolation':quantile(v,.9),'p95_linear_interpolation':quantile(v,.95),'minimum':min(v),'maximum':max(v)}
scheduled=[r for r in period if r['event']=='schedule'];gaps=[(dt(b['created_at'])-dt(a['created_at'])).total_seconds()/3600 for a,b in zip(scheduled,scheduled[1:])]
summary={'scope':'British Columbia needs-ID records with photos/coordinates; eligible changed-record deliveries, not photo changes',
 'observation_start':ordered[0]['created_at'],'observation_end':ordered[-1]['created_at'],
 'runs_available':len(rows),'logs_harvested':sum('sync'in r for r in rows),'conclusions':dict(collections.Counter(r['conclusion']for r in rows)),
 'analysis_UTC_days':len(days),'analysis_start':'2026-10-01','analysis_end':'2026-10-14','analysis_runs':len(period),'analysis_scheduled_runs':len(scheduled),
 'missing_scheduled_dates':[f'2026-10-{i:02d}'for i in range(1,15)if not any(r['utc_day']==f'2026-10-{i:02d}'for r in scheduled)],
 'scheduled_run_start_gap_hours':{'min':min(gaps),'max':max(gaps),'mean':statistics.mean(gaps)},
 'observed_query_overlap_hours':{'min':min(overlaps),'max':max(overlaps)},'daily_metrics':metrics,'daily':days,
 'caveats':['Added means entering the eligible pool, including re-entry, not necessarily a new observation or uncached photo.',
 'Replaced means eligible records fetched again, including intentional two-hour overlap, edits unrelated to photos, and manual reruns.',
 'Daily totals include manual dispatches and overlap duplicates, so they are conservative operational deliveries, not unique daily photo changes.',
 'All-grade fetched totals and photo URL/content deltas are not logged; eligible added+replaced bounds cache checks/new embeddings needed for this pool, not all iNaturalist records fetched.',
 'Only current map-state release exists; overwritten pool/sync assets cannot recover historical photo URL changes.',
 'Needs-ID pool workload does not bound adding or refreshing Research Grade reference embeddings.',
 'Fourteen daily observations cannot establish seasonal, annual, or future peak demand.',
 'Counters are actual logged transitions over variable query intervals, not historical updated_since API reconstructions.']}
(root/'enriched_runs.json').write_text(json.dumps(ordered,indent=2));(root/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items()if k not in ['daily','caveats']},indent=2))
print('DAILY',json.dumps(days,indent=2))
